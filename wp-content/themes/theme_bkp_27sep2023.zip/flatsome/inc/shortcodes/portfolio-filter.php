<?php

// [featured_items_slider]
function flatsome_portfolio_filter_shortcode($atts, $content = null, $tag) {

  extract(shortcode_atts(array(
        // meta
        'filter' => '',
), $atts));

	ob_start();
  wp_enqueue_script('flatsome-isotope-js');
?>
  <div class="container mb-half">
  <select class="nav nav-uppercase filter-nav">
    <option class="active" value="*"><?php echo __('All','flatsome'); ?></option>
    <?php
      $tax_terms = get_terms('featured_item_category');
      foreach ($tax_terms as $key => $value) {
         ?><option value="<?php echo $value->name; ?>"><?php echo $value->name; ?></option><?php
      }
    ?>
  </select>
  </div>
  <?php

  $content = ob_get_contents();
  ob_end_clean();
  return $content;
}
add_shortcode("ux_portfolio_filter", "flatsome_portfolio_filter_shortcode");
