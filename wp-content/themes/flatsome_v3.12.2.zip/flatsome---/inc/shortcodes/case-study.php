<?php

// [case-study]
function st_case_study($atts, $content = null) {

  extract(shortcode_atts(array(
    'per_page' => '2',
    'orderby' => 'date',
    'order' => 'desc',
  ), $atts));
  ob_start();

  $args = array(
      'post_per_page' => $per_page,
      'post_type' => 'casestudy',
      'post_status' => 'publish',
      'orderby' => $orderby,
      'order' => $order,
  );

  $loop = new WP_Query( $args ); 
  echo '<div class="case-study">';
  while ( $loop->have_posts() ) : $loop->the_post(); 
  ?>
    <div class="case-study-box">
         <?php 
         $featured_img = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full', false, '' );
         ?>
         <?php if($featured_img) { ?>
          <div class="icon-box-img case-study-image" style="<?php if($image_width) echo $image_width; ?>">
                <img src="<?php echo $featured_img[0] ?>" width="<?php echo $featured_img[1] ?>" height="<?php echo $featured_img[2] ?>" />
          </div>
        <?php } ?>
        <div class="right-part">
          <h3 class="case-title title-divider"><?php echo get_the_title() ?></h3>
          <?php the_content() ?>
          <a href="#" class="btn-readmore case-study-readmore">Read More</a>
        </div>
    </div>
  <?php
  endwhile;
  echo '</div>';
  wp_reset_postdata();
  $content = ob_get_contents();
  ob_end_clean();
  return $content;
}

add_shortcode("case-study", "st_case_study");

