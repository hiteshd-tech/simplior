<?php

// [testimonial-slider]
function st_testimonial($atts, $content = null)
{
    $sliderrandomid = rand();
    extract(shortcode_atts(array(
    'name' => '',
    'class' => '',
    'visibility' => '',
    'company' => '',
    'stars' => '5',
    'font_size' => '',
    'text_align' => '',
    'image'  => '',
    'image_width' => '80',
    'pos' => 'left',
    'link' => '',
    'hide_nav' => '',
    'nav_pos' => '',
    'nav_style' => 'circle',
    'nav_color' => 'light',
    'nav_size' => 'large',
    'arrows' => 'true',
    'bullets' => 'true',
    'bullet_style' => '',
    ), $atts));
    ob_start();

    $classes = array('testimonial-box');

    $classes[] = 'slider';

    // Bullet style
    if ($bullet_style) {
        $classes[] = 'slider-nav-dots-'.$bullet_style;
    }

    // Nav style
    if ($nav_style) {
        $classes[] = 'slider-nav-'.$nav_style;
    }

    // Nav size
    if ($nav_size) {
        $classes[] = 'slider-nav-'.$nav_size;
    }

    // Nav Color
    if ($nav_color) {
        $classes[] = 'slider-nav-'.$nav_color;
    }

    // Nav Position
    if ($nav_pos) {
        $classes[] = 'slider-nav-'.$nav_pos;
    }

    // Always show Nav if set
    if ($hide_nav ==  'true') {
        $classes[] = 'slider-show-nav';
    }

    // Slider Nav visebility
    $is_arrows = 'true';
    $is_bullets = 'true';

    if ($arrows == 'false') {
        $is_arrows = 'false';
    }
    if ($bullets == 'false') {
        $is_bullets = 'false';
    }

    $classes_img = array('icon-box-img','testimonial-image','circle');
  
    $classes[] = 'icon-box-'.$pos;
    if ($class) {
        $classes[] = $class;
    }
    if ($visibility) {
        $classes[] = $visibility;
    }

    if ($pos == 'center') {
        $classes[] = 'text-center';
    }
    if ($pos == 'left' || $pos == 'top') {
        $classes[] = 'text-left';
    }
    if ($pos == 'right') {
        $classes[] = 'text-right';
    }
    if ($font_size) {
        $classes[] = 'is-'.$font_size;
    }
    if ($image_width) {
        $image_width = 'width: '.intval($image_width).'px';
    }

    $classes = implode(" ", $classes);
    ?>
  <div class="slider-wrapper relative" id="testimonial-slider">
    <div class="<?php echo $classes ?>"
        data-flickity-options='{
            "cellAlign": "center",
            "imagesLoaded": true,
            "freeScroll": false,
            "wrapAround": true,
            "autoPlay": 6000,
            "pauseAutoPlayOnHover" : true,
            "prevNextButtons": <?php echo $is_arrows; ?>,
            "contain" : true,
            "adaptiveHeight" : true,
            "dragThreshold" : 10,
            "percentPosition": true,
            "pageDots": <?php echo $is_bullets; ?>,
            "rightToLeft": false,
            "draggable": true,
            "selectedAttraction": 0.1,
            "parallax" : 0,
            "friction": 0.6
        }'
    >
    <?php
    $args = array(
      'post_type' => 'testimonials',
      'post_status' => 'publish',
    );

    $loop = new WP_Query($args);
  
    while ($loop->have_posts()) :
        $loop->the_post();
        $company_name = get_post_meta(get_the_ID(), 'company_name', true);
        $total_review = get_post_meta(get_the_ID(), 'total_review', true);

        $star_row = '';
        if ($total_review == '1') {
            $star_row = '<div class="star-rating"><span style="width:12%"><strong class="rating"></strong></span></div>';
        } elseif ($total_review == '2') {
            $star_row = '<div class="star-rating"><span style="width:23%"><strong class="rating"></strong></span></div>';
        } elseif ($total_review == '3') {
            $star_row = '<div class="star-rating"><span style="width:39%"><strong class="rating"></strong></span></div>';
        } elseif ($total_review == '4') {
            $star_row = '<div class="star-rating"><span style="width:49%"><strong class="rating"></strong></span></div>';
        } elseif ($total_review == '5') {
            $star_row = '<div class="star-rating"><span style="width:100%"><strong class="rating"></strong></span></div>';
        }

        ?>
    <div class="icon-box <?php echo $classes; ?> st-testimonial">
          <div class="testimonial-text line-height-small italic test_text first-reset last-reset is-italic">
              <?php the_content(); ?>
          </div>
          <?php
            $featured_img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'thumb', false, '');
            ?>
          <div class="icon-text-image">
            <?php if ($featured_img) { ?>
            <div class="icon-box-img testimonial-image circle" style="<?php if ($image_width) {
                echo $image_width;
                                                                      } ?>">
              <img src="<?php echo $featured_img[0] ?>" width="<?php echo $featured_img[1] ?>" height="<?php echo $featured_img[2] ?>" alt="<?php echo get_the_title() ?>" title="<?php echo get_the_title() ?>" />
            </div>
            <?php } ?>
            <div class="icon-box-text p-last-0">
              <?php if ($stars > 0) {
                    echo $star_row;
              } ?>
              <div class="testimonial-meta pt-half">
                  <strong class="testimonial-name test_name"><?php echo get_the_title(); ?></strong>
                  <?php if ($company_name) { ?>
                    <span class="testimonial-company"><span class="testimonial-name-divider"></span><?php echo $company_name; ?></span>
                  <?php } ?>
              </div>
            </div>
          </div>
    </div>
        <?php
    endwhile;
    wp_reset_postdata();
    ?>
  </div>
  </div>
    <?php
    $content = ob_get_contents();
    ob_end_clean();
    return $content;
}

add_shortcode("testimonial-slider", "st_testimonial");

